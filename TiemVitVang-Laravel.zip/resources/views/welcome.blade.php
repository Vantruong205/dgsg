<!-- Trang chủ giao diện menu đồ uống Tiệm Vịt Vàng -->
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tiệm Vịt Vàng - Menu Đồ Uống</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #fffdee; color: #333; font-family: 'Segoe UI', sans-serif; }
    .navbar { background-color: #ffcc00; }
    .menu-card { border-radius: 20px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); transition: transform 0.2s; }
    .menu-card:hover { transform: scale(1.03); }
    .price { color: #4caf50; font-weight: bold; }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <a class="navbar-brand fw-bold text-white" href="#">Tiệm Vịt Vàng</a>
      <div>
        <a href="#" class="btn btn-outline-light">Đăng nhập</a>
        <a href="#" class="btn btn-light ms-2">Tạo tài khoản</a>
      </div>
    </div>
  </nav>

  <div class="container py-5">
    <h2 class="text-center mb-4">Menu Đồ Uống</h2>
    <div class="row g-4">
      <div class="col-md-3">
        <div class="card menu-card">
          <img src="https://source.unsplash.com/300x200/?milk-tea" class="card-img-top" alt="">
          <div class="card-body">
            <h5 class="card-title">Trà sữa trân châu</h5>
            <p class="price">35.000đ</p>
            <button class="btn btn-success w-100">Thêm vào giỏ</button>
          </div>
        </div>
      </div>
      <!-- Thêm nhiều món tại backend hoặc sao chép thêm tại đây -->
    </div>
  </div>
</body>
</html>
